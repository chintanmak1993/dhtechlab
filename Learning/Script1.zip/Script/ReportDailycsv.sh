HCLog=/u02/Report_Data/HC;
DisLog=/u02/Report_Data/DIS_EPS;
ParLog=/u02/Report_Data/EPS;
ReportPath=/u02/Report_Data/Final_EPS_Report
DAY=`date -d "-1 days" +%Y%m%d`;
echo -e "*********************************************************************">${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "************* TataSky STL Daily Status Report ***********************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "              Created By  : Chintan Makwana/Avaneesh T               ">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "	      Report Date : ${DAY}                                   ">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "              Project M   : Uday Patil                               ">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "**************************Daily EPS**********************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

echo -e "Circle,Date,Total RecordCount,Peak EPS">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
for i in {MUM1,MUM2,CHE1,CHE2,KOL1,KOL2,PUN1,PUN2,DEL1,DEL2,JAI1,JAI2}
do
k=`find $ParLog/${i}/ -type f -iname "**${DAY}*.log" -exec cat {} \;|grep ${DAY}`
echo -e "${i},${k}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
done
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*******************RECON STATS FOR NAT RECORD************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "Circle,Date,File Count,Total Record Count,Size(GB),EPS">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
for i in {MUM1,MUM2,CHE1,CHE2,KOL1,KOL2,PUN1,PUN2,DEL1,DEL2,JAI1,JAI2}
do
k=`find $DisLog/${i}/ -type f -iname "**${DAY}*" -exec cat {} \;|tail -1|cut -d',' -f 2,3,4,5,6,7`
echo -e "${i},${k}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
done

echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************** Disk Stats **********************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "date,hostname,Server IP,/,/App-log,/u01,/boot,/opt,/dev/shm,/var,/home">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
for i in {MUM1,MUM2,CHE1,CHE2,KOL1,KOL2,PUN1,PUN2,DEL1,DEL2,JAI1,JAI2}
do
k=`find $HCLog/${i}/ -type f -iname "**${DAY}*" -exec cat {} \;|grep systemdisk|grep ${DAY}|tail -1|cut -d',' -f2,3,4,5,6,7,8,9,10,11`
echo -e "${k}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
done


echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************** Memory Stats ********************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "date,hostname,serverIP,total Memory,Total Free memory, total used memory">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
for i in {MUM1,MUM2,CHE1,CHE2,KOL1,KOL2,PUN1,PUN2,DEL1,DEL2,JAI1,JAI2}
do
k=`find $HCLog/${i}/ -type f -iname "**${DAY}*" -exec cat {} \;|grep systemmemory|grep ${DAY}|tail -6|head -1|cut -d',' -f2,3,5,6,7,8`
echo -e "${k}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
done


echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************** CPU Stats ***********************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "Date,HostName,ServerIP,Load Avg1 ,Load Avg2,Load Avg3">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
for i in {MUM1,MUM2,CHE1,CHE2,KOL1,KOL2,PUN1,PUN2,DEL1,DEL2,JAI1,JAI2}
do
k=`find $HCLog/${i}/ -type f -iname "**${DAY}*" -exec cat {} \;|grep systemload|grep ${DAY}|tail -6|head -1|cut -d',' -f2,3,4,5,6,7`
echo -e "${k}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
done

echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************** EPS Hourly  ********************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log
echo -e "*********************************************************************">>${ReportPath}/Report_${DAY}_TataSkyBB.Log


    while read INPUT ; do
            echo "MUM1,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/MUM1/Recon_TataSkyMUM_1_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "MUM2,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/MUM2/Recon_TataSkyMUM_2_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "DEL1,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/DEL1/Recon_TataSkyDEL_1_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "DEL2,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/DEL2/Recon_TataSkyDEL_2_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "CHE1,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/CHE1/Recon_TataSkyChennai_1_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "CHE2,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/CHE2/Recon_TataSkyChennai_2_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "JAI1,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/JAI1/Recon_TataSkyJaipur_1_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "JAI2,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/JAI2/Recon_TataSkyJaipur_2_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "PUN1,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/PUN1/Recon_TataSkyPune_1_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "PUN2,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/PUN2/Recon_TataSkyPune_2_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "KOL1,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/KOL1/Recon_TataSkyKOL_1_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log

     while read INPUT ; do
            echo "KOL2,${INPUT//,/,}">>${ReportPath}/Report_${DAY}_TataSkyBB.Log ;
    done < ${ParLog}/KOL2/Recon_TataSkyKOL_2_${DAY}.log ;
    echo "</table>">>${ReportPath}/Report_${DAY}_TataSkyBB.Log




