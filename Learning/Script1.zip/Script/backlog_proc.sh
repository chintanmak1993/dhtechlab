#! /bin/bash
ulimit -s 50000
src=/u01/COLLECTION/INPUT/PARSE_ROOT/ARCH_bkp/
dst=/u01/COLLECTION/INPUT/PARSE_ROOT/OUTPUT/
tmp=/u01/COLLECTION/INPUT/PARSE_ROOT/ARCH/
#while [ `find ${src} -name '*.gz' -type f | wc -l` != 0 ]
#do
hfc=`find ${src} -name '*.gz' -type f |awk -F '_' '{print $4}'|cut -b 1-10|sort|uniq|tail -1`
#dst_cnt=`find ${dst} -type f | wc -l`
#tmp_cnt=`find ${tmp} -type f | wc -l`
#if [ $dst_cnt -le 50 -a $tmp_cnt -le 10 ]
#then
cd ${src}
mv `ls *${hfc}*.gz.gz |head -100` ${dst}
sh /opt/iplms/script/DNS_FILTER.sh
#else echo "more file in ${dst}"
#exit
#fi
#done
