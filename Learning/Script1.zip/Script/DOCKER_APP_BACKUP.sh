#!/bin/bash

dd=`date +"%d/%b/%Y %H:%M"`

ddate=`date +"%Y%m%d_%H%M"`

container_name=Engine_7.10.19

Backup_path=/u01/APPLICATION_BKP
ENV_Path=/u01/STL_setup/

docker commit -m "engine_bkp at $dd" $container_name engine_$ddate
cd $Backup_path/
docker save -o engine_$ddate engine_$ddate
docker rmi engine_$ddate

cp -r $ENV_Path/mediation $Backup_path
find $Backup_path -iname "*" -type f -mtime +7 -exec rm -rf {} \; &