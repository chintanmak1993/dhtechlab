#!/bin/sh
lock_path=/tmp/
############# LOCK FILE ########################
if test -f ${lock_path}.central_sftp_move_dest1.lock
        then
                echo "script is already running"
                exit
        else
                echo " creating lock file "
                touch ${lock_path}.centrtal_sftp_move_dest1.lock
fi;
echo -e `date`
echo "Script Execution Start"
DEST1=10.209.94.81
FC=5000
LOCAL_FOLDER=/u02/VF_distributed
REMOTE_FOLDER=/CGNATDATA/NONCORRELATED/EDRAI/CGNAT/Input
LOG=/opt/crestelsetup/crestelpengine/modules/mediation/logs/rsync/
SEND_DATE=`date '+%Y%m%d'`

mkdir -p ${LOG}

FileSRC=`find $LOCAL_FOLDER/ -type f -iname "*.gz"  |head -${FC}`

cd $LOCAL_FOLDER
for i in ${FileSRC}
do
cp ${i} ${i}.done
done

echo -e "File Copied to All Temp Folder"

echo `date`
echo "File Transfer start to First Destination"
ulimit -s 10000000;sshpass -p 'edgesites@123' rsync --remove-sent-files -av -e ssh ${LOCAL_FOLDER}/*.gz edgesites@${DEST1}:${REMOTE_FOLDER} --log-file=${LOG}INTELLEZA_FILE_${SEND_DATE}_Dest1.log
rm ${lock_path}.central_sftp_move_dest1.lock
echo "LOCK IS REMOVED"