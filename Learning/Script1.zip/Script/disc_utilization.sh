
hostname=`hostname`
log=/u02/Report_Data/HC/BAN_VIEWER1
. /home/docker/Scripts/color.cr
echo -e "\n" >>${log}/${hostname}_${DAY}_su.csv
FREE=`free -g  | sed -n '2,2p' | awk ' { print $4 } '`
USED=`free -g  | sed -n '2,2p' | awk ' { print $3 } '`
TOTAL=`free -g  | sed -n '2,2p' | awk ' { print $2 } '`
InCache=`free -g  | sed -n '2,2p' | awk ' { print $6 } '`
TotalSwap=`free -g  | sed -n '3,3p' | awk ' { print $2 } '`
FreeSwap=`free -g  | sed -n '3,3p' | awk ' { print $4 } '`
DAY=`date +%Y%m%d`;
date >>${log}/${hostname}_${DAY}_su.csv

echo -e systemmemory,date,hostname,serverIP,total Memory,Total Free memory,UsedMemory,TotalInCache,TotalSwap,TotalFreeSwap >>${log}/${hostname}_${DAY}_su.csv
echo -e systemmemory,"$DAY,`hostname`-VIEWER1,`hostname`,`hostname -i`,${TOTAL},$FREE,$USED,$InCache,$TotalSwap,$FreeSwap" >>${log}/${hostname}_${DAY}_su.csv

. /home/docker/Scripts/color.cr
THRESOLD=70
LOAD=`uptime`
TEST=`uptime |awk -F ',' '{print$5}'|awk -F '.' '{print$1}'`
uptime1=`uptime |awk -F ',' '{print$4}'|cut -d ':' -f2`
uptime2=`uptime |awk -F ',' '{print$5}'|cut -d ':' -f2`
uptime3=`uptime |awk -F ',' '{print$6}'|cut -d ':' -f2`

ServerUp=`uptime |awk -F ',' '{print$1}'|awk -F ' ' '{print$3" "$4}'`

echo -e systemload,date,hostname,serverIPuptime1,uptime2,uptime3,ServerUpSince >>${log}/${hostname}_${DAY}_su.csv
echo -e systemload,"$DAY,`hostname`-VIEWER1,`hostname -i`,$uptime1,$uptime2,$uptime3,$ServerUp" >>${log}/${hostname}_${DAY}_su.csv
. /home/docker/Scripts/color.cr


THRESHOLD=70
CC=`df -P|grep "/"|awk  '{print$6,"-->>",$5}'|sed 's/%//g'|wc -l`


echo "systemdisk,date,hostname,Server IP,/,/u02,/boot,/dev/shm,/var,/home,/pri_iplms_data1,/pri_iplms_data2,/IPLMS-1,/IPLMS-2,/IPLMS-3,/IPLMS-4,/IPLMS-5 " >>${log}/${hostname}_${DAY}_su.csv
root=`df -P|grep "/"|grep "/dev/sda3" |awk  '{print$5}'`
#Applog=`df -P|grep "/"|grep "/App-log" |awk  '{print$5}'`
u02=`df -P|grep "/" |grep "/u02" |awk  '{print$5}'`
boot=`df -P|grep "/" |grep "/boot" |awk  '{print$5}'| head -1`
#opt=`df -P|grep "/" |grep "/opt" |awk  '{print$5}'`
dev_shm=`df -P|grep "/" |grep "/dev/shm" |awk  '{print$5}'`
var=`df -P|grep "/" |grep "/dev/sda4" |awk  '{print$5}'`
home=`df -P|grep "/" |grep "/home" |awk  '{print$5}'`
pri_iplms_data1=`df -P|grep "/" |grep "/pri_iplms_data1" |awk  '{print$5}'`
pri_iplms_data2=`df -P|grep "/" |grep "/pri_iplms_data2" |awk  '{print$5}'`
IPLMS1=`df -P|grep "/" |grep "/IPLMS-1" |awk  '{print$5}'`
IPLMS2=`df -P|grep "/" |grep "/IPLMS-2" |awk  '{print$5}'`
IPLMS3=`df -P|grep "/" |grep "/IPLMS-3" |awk  '{print$5}'`
IPLMS4=`df -P|grep "/" |grep "/IPLMS-4" |awk  '{print$5}'`
IPLMS5=`df -P|grep "/" |grep "/IPLMS-5" |awk  '{print$5}'`
echo -e "systemdisk,$DAY,`hostname`-VIEWER1,`hostname -i`,$root,$u02,$boot,$dev_shm,$var,$home,$pri_iplms_data1,$pri_iplms_data2,$IPLMS1,$IPLMS2,$IPLMS3,$IPLMS4,$IPLMS5 " >>${log}/${hostname}_${DAY}_su.csv

echo -e "\n" >>${log}/${hostname}_${DAY}_su.csv

BASE_DIR="/u02/"
TOTAL_FILES=0
YDAY=`date -d "-1 days" +%Y%m%d`;
PHour=`date -d "-1 days" +"%-H"`
TODAY=`date +%Y%m%d`;
MAX_ALLOWED_FILES=1
echo PendingFilecount,ServerHostname,ServerIP,PendingFilePath,PendingFileCount >>${log}/${hostname}_${DAY}_su.csv
for file in `find $BASE_DIR -type d|grep -v STAT|grep -v Report_Data| grep -v Pri_Search_Result|grep -v APPLOG |grep -v Collector_Backup|grep -v EXP_BKP|grep -v APPLICATION_BACKUP | grep -v DB_Backup| grep -v {YDAY}|grep -v ${TODAY}`
do
		  TOTAL_FILES=`find $file -maxdepth 1 -type f |grep -v {YDAY}|grep -v ${TODAY}| wc -l`
		  	    if test $TOTAL_FILES -ge $MAX_ALLOWED_FILES
				    		      then
							      			        echo PendingFilecount-${PHour},`hostname`-VIEWER1,`hostname -i`,$file,$TOTAL_FILES >>${log}/${hostname}_${DAY}_su.csv
															  fi
															  			  done


echo -e "\n" >>${log}/${hostname}_${DAY}_su.csv
