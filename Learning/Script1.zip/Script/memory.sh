
. /opt/crestelsetup/Script/color.cr
FREE=`free -g  | sed -n '2,2p' | awk ' { print $4 } '`
USED=`free -g  | sed -n '2,2p' | awk ' { print $3 } '`
TOTAL=`free -g  | sed -n '2,2p' | awk ' { print $2 } '`
DAY=`date +%Y%m%d`;

echo -e date,hostname,total Memory,Total Free memory, total used memory
echo -e "${SK}$DAY, `hostname`, ${N}${R}${BL}${TOTAL},${N}$FREE,${N}$USED"

