#!/bin/bash
src_path=/u01/COLLECTION/INPUT/backup/
dst_path=/u01/COLLECTION/INPUT/192.168.210.65

for file in $src_path/Test*.gz
do
mv $file $dst_path
sleep 3
done
