rsync --remove-sent-files -av -e ssh /u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT_bkp/*202109150*.gz docker@192.168.81.31:/pri_iplms_data1/NATDATA_RAW &
rsync --remove-sent-files -av -e ssh /u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT_bkp/*202109151*.gz docker@192.168.81.31:/pri_iplms_data1/NATDATA_RAW &
rsync --remove-sent-files -av -e ssh /u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT_bkp/*202109152*.gz docker@192.168.81.31:/pri_iplms_data1/NATDATA_RAW &
rsync --remove-sent-files -av -e ssh /u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT_bkp/*202109160*.gz docker@192.168.81.31:/pri_iplms_data1/NATDATA_RAW &
rsync --remove-sent-files -av -e ssh /u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT_bkp/*202109161*.gz docker@192.168.81.31:/pri_iplms_data1/NATDATA_RAW &
