#!/bin/sh

path=/pri_iplms_data1/TEST

FILE=`find $path -type f -iname "*gz" |head -100`

for i in $FILE

do
CIRCLE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $1}'`
DATE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $3}'| cut -b 1-8`
#mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
#mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
if [ $CIRCLE == tatasky3 ]; then
CIRCLE=MUM
DATE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $2}'| cut -b 1-8`
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/TEST-1/MUM/$DATE

elif [ $CIRCLE == DEL  ]; then
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/TEST-1/DEL/$DATE

elif [ $CIRCLE == KOL  ]; then
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/TEST-1/KOL/$DATE

elif [ $CIRCLE == PUN  ]; then
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/TEST-1/PUN/$DATE

elif [ $CIRCLE == JAI  ]; then
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/TEST-1/JAI/$DATE

elif [ $CIRCLE == NOI  ]; then
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/TEST-1/NOI/$DATE

elif [ $CIRCLE == SYSLOG01  ]; then
CIRCLE=BAN
DATE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $2}'| cut -b 1-8`
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE
mkdir -p /pri_iplms_data1/TEST-1/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/TEST-1/BAN/$DATE

else
echo "other circle files are present"

fi

done


### To transfer file from one server to another
##   A=$(ssh -l ${USERNAME) ${HOSTNAME} 'cd or mkdir -p /sec-iplms/test/$CIRCLE/$DATE')
## rsync -auz /pri_iplms_data1/TEST-1/PUN/$DATE/*.gz ${USERNAME}@${HOSTNAME}/sec-iplms/test/PUN/$DATE/
