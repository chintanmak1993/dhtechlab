#! /bin/bash
ulimit -s 100000
src=/pri_iplms_data1/NATDATA_RAW/
dst=/pri_iplms_data1/NATDATA_BACKLOG/
dst_cnt=`find ${dst} -type f | wc -l`
if [ $dst_cnt -le 50 ]
then
hfcs=`find ${src} -name '*.gz' -type f |awk -F '_2021' '{print$2}'|cut -b 1-6|sort|sed -e 's/^/2021/'|uniq -c|awk '{print $2}'|tail -1`
mv `ls ${src}*${hfcs}*.gz` $dst
else echo "more file in ${dst}"
echo -e  "File moved for processing : $dst_cnt"
exit
fi
