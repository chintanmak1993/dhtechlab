#!/bin/sh
. /opt/iplms/script/color.cr
P1=/u01/COLLECTION/INPUT/192.168.210.65
P2=/opt/iplms/crestelsetup/CRESTEL-P-Engine/modules/mediation/logs
P3=/u01/COLLECTION/INPUT/error/DISTRIBUTION_SERVICE-000-SFTP_DISTRIBUTION_DRIVER-0/192.168.210.65-001/DEFAULT/FILE/2019/.
P4=/u01/COLLECTION/INPUT/archived/2019/.

C1=`find $P1 -type f |wc -l`
C2=`find $P2 -type f |wc -l`
C3=`find $P3 -type f |wc -l`
C4=`find $P4 -type f -mtime +90|wc -l`

echo -e "${BA}CIRCLE :|| $HOSTNAME:`hostname -i` ||${N}\n "COLLECTION-PATH_65" ${G}$P1${N} --> ${SK}$C1${N}\n "Total-log-Files"  ${G}$P2${N} --> ${SK}$C2${N}\n "COLL_192.168.81.65_error" ${G}$P3${N} --> ${R}$C3${N}\n "Files in Archive" ${G}$P4${N} --> ${SK}$C4${N}\n"

