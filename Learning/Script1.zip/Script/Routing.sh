#!/bin/sh
res1=$(date +%s.%N)
#########################################################
SRC=/u01/COLLECTION/INPUT/DIST_ARCH/archived/
DEST1=/u01/COLLECTION/INPUT/DIST_ARCH/ARCH_PURGE/
DEST2=/u01/COLLECTION/INPUT/DIST_ARCH/ARCH_PURGE/
THRESHOLD_DEST1=300
THRESHOLD_DEST2=800
LOG_FILE=/App-log/ROUTE_LOGS/
DATE=`date '+%c'`
lock_path=/tmp/
ID=/tmp/file
#########################################################


############################checking lock file #####################

if test -f ${lock_path}.SPLIT.lock
        then
                echo "script is already running"
                exit
        else
                echo " creating lock file "
                touch ${lock_path}.SPLIT.lock
fi;

####################################################################

######################## Cheking free memory #####################
MEM=`free -g|grep Mem|awk -F ' ' '{print$3}'`
MEM1=`free -g|grep Mem|awk -F ' ' '{print$2}'`
T=`expr $MEM \* 100`
C=`expr $T / $MEM1`

if [ $C -ge 99 ];then
echo -e "Memory utilization of $HOSTNAME crosses \033[5m ${C}% \033[0m "
echo 3 > /proc/sys/vm/drop_caches
rm ${lock_path}.SPLIT.lock
exit
fi

#######################################################################
echo "Start running on $DATE"

move_files () {
DAY=`ls  ${SRC}|awk -F '_' '{print$2}'|cut -c1,2,3,4,5,6,7,8|sort|uniq|head -1`
FILE=`find $SRC -type f -iname "*_${DAY}*.gz"|head -800`

for i in $FILE
do
DATE1=`echo ${i}|awk -F '/' '{print$7}'|awk -F '_' '{print$2}'|cut -c1,2,3,4,5,6,7,8`
FNAME=`echo ${i}|awk -F '/' '{print$7}'`
CC=`zcat ${i}|wc -l`
SIZE=`du -b ${i}|awk '{print$1}'`
DD=`ls -l ${i}|awk -F ' ' '{print$6,$7,$8}'`
#ID=`zcat ${i} | awk -F ',' '{print $9}'`
########zcat ${i} | awk -F ',' '{print $9}'> $ID
########C6=`cat $ID | grep -c 260 &`
########D6=`cat $ID | grep -c 261 &`
########C4=`cat $ID | grep -c 271 &`
########D4=`cat $ID | grep -c 272 &`

#####CC=$(($C4+$D4+$C6+$D6))

echo "$DD,$FNAME,$SIZE,$CC" >> ${LOG_FILE}TATASKY_MUMBAI1_RECON_${DATE1}.csv
mv -v ${i} ${1}
#mv -v ${i} ${1}${FNAME}.inprocess
#cd ${1};rename .gz.inprocess .gz *.inprocess
done
}

if [ -d $SRC ] ;then

        move_files ${DEST1}

fi
echo "Completed"

echo "#################################################################"
res2=$(date +%s.%N)
dt=$(echo "$res2 - $res1" | bc)
dd=$(echo "$dt/86400" | bc)
dt2=$(echo "$dt-86400*$dd" | bc)
dh=$(echo "$dt2/3600" | bc)
dt3=$(echo "$dt2-3600*$dh" | bc)
dm=$(echo "$dt3/60" | bc)
ds=$(echo "$dt3-60*$dm" | bc)

printf "Total runtime: %d:%02d:%02d:%02.4f\n" $dd $dh $dm $ds

echo "#################################################################"

rm ${lock_path}.SPLIT.lock
