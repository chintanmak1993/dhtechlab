#!/bin/bash
source_path=/u01/COLLECTION/INPUT/PROC_ROOT/error/DISTRIBUTION_SERVICE-000-SFTP_DISTRIBUTION_DRIVER-0/OUTPUT-000/DEFAULT/FILE/
for i in `find $source_path -type f -iname "*.gz"`;
do
rsync --remove-sent-files -av -e ssh $i /u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT
done


source_path1=/u01/COLLECTION/INPUT/PROC_ROOT/error/DISTRIBUTION_SERVICE-000-SFTP_DISTRIBUTION_DRIVER-0/OUTPUT-000/DEFAULT_COMPOSER_PLUGIN-1/FILE/
for i in `find $source_path1 -type f -iname "*.gz"`;
do
rsync --remove-sent-files -av -e ssh $i /u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT
done

