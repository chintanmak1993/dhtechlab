#!/bin/sh
LOCAL_FOLDER=/u01/Recon_tatasky_Distribution
REMOTE_FOLDER=/u02/Report_Data/DIS_EPS/MUM1
echo $LOCAL_FOLDER
echo $REMOTE_FOLDER
cd $LOCAL_FOLDER
for file in `ls -1 *summary.csv`
do
sshpass -p  docker sftp docker@192.168.81.31 > $LOCAL_FOLDER/ftp2RECON.log << eofa
cd $REMOTE_FOLDER
mput $file
bye
eofa
sshpass -p  docker sftp docker@192.168.81.33 > $LOCAL_FOLDER/ftp2RECON.log << eofa
cd $REMOTE_FOLDER
mput $file
bye
eofa

mv $file $file.Done
done
