SRC=/u01/COLLECTION/INPUT/PARSE_ROOT/DNS_IN
TEMP=/u01/COLLECTION/INPUT/PARSE_ROOT/DNS_TMP
DEST=/u01/COLLECTION/INPUT/PARSE_ROOT/DNS_OUT

#mkdir -p $SRC
#mkdir -p $TEMP
#mkdir -p $DEST
cd $SRC/

fileT=`find . -type f -iname "*.gz"`

for i in  $fileT
do
mv $SRC/$i $TEMP/$i.csv.gz
gunzip $TEMP/*.gz

for k in `ls -1 $TEMP/*.csv`
do
sed -i 's/,,/,/g' $k
#gzip $k
done
mv $TEMP/*.csv $DEST/
done
