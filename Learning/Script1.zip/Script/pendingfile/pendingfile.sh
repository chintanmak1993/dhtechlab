#!/bin/bash
DATE=`date +%Y%m%d-%H:%M`
cd /opt/iplms/script/pendingfile
rm pending_files*.log
find /u01/ -type f -name Test* -mmin +60 |awk -F 'Test' '{print $1}' | egrep -v 'NATDATA|archived' |sort -u >>pending_files$DATE.log
>pendingfile_count.txt
echo -e "\t \t \t \t MUM-COLLECTOR-1[$DATE]" >>pendingfile_count.txt
echo "---------------------------------------------------------------------------------------------------------" >>pendingfile_count.txt
echo "Server uptime:" >>pendingfile_count.txt
uptime >>pendingfile_count.txt
echo "---------------------------------------------------------------------------------------------------------" >>pendingfile_count.txt
for i in `cat pending_files$DATE.log`
do
	echo $i:--\> `cd $i;ls|wc -l` >>pendingfile_count.txt
done
sed -i '/DNSFILTER/d' ./pendingfile_count.txt
echo "---------------------------------------------------------------------------------------------------------" >>pendingfile_count.txt

ssh docker@192.168.81.31 "cat >> /home/docker/Scripts/pendingfile/pendingfile_pri_$DATE.txt" < pendingfile_count.txt
