#!/bin/sh

path=/IPLMS-1/RAW_FILES_ALL_CIRCLES
USERNAME=root
HOSTNAME=root123
FILE=`find $path -type f -iname "*gz" |head -300`

for i in $FILE

do
CIRCLE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $1}'`
DATE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $3}'| cut -b 1-8`
#mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
#mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
if [ $CIRCLE == tatasky3 ]; then
CIRCLE=MUM
DATE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $2}'| cut -b 1-8`
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/MUM/$DATE

elif [ $CIRCLE == CHN  ]; then
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/CHN/$DATE

elif [ $CIRCLE == DEL  ]; then
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/DEL/$DATE

elif [ $CIRCLE == KOL  ]; then
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/KOL/$DATE

elif [ $CIRCLE == PUN  ]; then
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/PUN/$DATE

elif [ $CIRCLE == JAI  ]; then
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/JAI/$DATE

elif [ $CIRCLE == NOI  ]; then
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/NOI/$DATE

elif [ $CIRCLE == SYSLOG01  ]; then
CIRCLE=BAN
DATE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $2}'| cut -b 1-8`
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/BAN/$DATE

elif [ $CIRCLE == SYSLOG02  ]; then
CIRCLE=BAN
DATE=`echo ${i}|awk -F "/" '{print $4}' |awk -F "_" '{print $2}'| cut -b 1-8`
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE
mkdir -p /pri_iplms_data1/CIRCLE/$CIRCLE/$DATE
rsync --remove-source-files -auz $i /pri_iplms_data1/CIRCLE/BAN/$DATE

else
echo "other circle files are present"

fi

done


### To transfer file from one server to another
##   A=$(ssh -l ${USERNAME) ${HOSTNAME} 'cd or mkdir -p /sec-iplms/test/$CIRCLE/$DATE')
## rsync -auz /pri_iplms_data1/CIRCLE/PUN/$DATE/*.gz ${USERNAME}@${HOSTNAME}/sec-iplms/test/PUN/$DATE/
