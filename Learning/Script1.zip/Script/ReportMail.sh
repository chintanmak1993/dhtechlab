ReportPath=/u02/Report_Data/Final_EPS_Report;
cd /u02/Report_Data/Final_EPS_Report/;
DAY=`date -d "-1 days" +%Y%m%d`;
echo -e "Dear Team,\n\nPlease find the IPLMS Daily Operation Report.\n\nRegards,\nTeam STL" | mailx -S "smtp=192.168.54.59" -v  -r notification@tataskybb.com -s "TSBB Daily IPLMS Report" -a "Report_${DAY}_TataSkyBB.html" "jayesh.shah@stl.tech, jayasudha.mudaliar@stltech.in, chintan.makwana@stl.tech, pog.mediation@stl.tech, sterliteusers@tataskybb.com, Navin.Fernandes@tataskybb.com, uday.patil1@stl.tech, omkar.mugdar@stltech.in, shailesh.savla@stl.tech, hardik.patel1@stl.tech, ninad.parab@stl.tech, sandhya.sharma@stl.tech, jayesh1912.shah@gmail.com, ankit.kumar5@stl.tech"
