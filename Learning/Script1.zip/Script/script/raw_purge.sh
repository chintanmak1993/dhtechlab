find /u01/NATDATA/SYSLOG/COLLECTION/archived/. -iname "*.gz" -type f -mtime +15 -exec rm -rf {} \; &
find /u01/NATDATA/SYSLOG/JUNIPER/Parse-Arch/archived/. -iname "*.gz" -type f -mtime +10 -exec rm -rf {} \; &
#find /u01/NATDATA/SYSLOG/JUNIPER/Dist-ARCH/archived/. -iname "*.gz" -type f -mtime +15 -exec rm -rf {} \; &
find /u01/NATDATA/SYSLOG/JUNIPER/Dist-ARCH/ARCH_PURGE/. -iname "*.gz" -type f -mtime +10 -exec rm -rf {} \; &
#find /u01/NATDATA/SYSLOG/JUNIPER/error/Parsing-Input-000/ASCII_PARSING_PLUGIN-1/ -type f -name KOL* -mtime +7 -exec rm -rf {} \; &
find /u01/NATDATA/SYSLOG/JUNIPER/filtered/. -iname "*.inp" -type f -mtime +1 -exec rm -rf {} \; &
