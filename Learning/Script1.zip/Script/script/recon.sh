#!/bin/sh
DATE1=`date -d "now -1 day" "+%d %m %Y"`
DAY=`date -d 'now -1 DAY' '+%Y%m%d'`
YYYY=`date '+%Y'`
MM=`date '+%m'`
DD=`date '+%d'`
SRC1=/u01/NATDATA/D_SYSLOG/JUNIPER/Dist-ARCH/archived/
SRC2=/u02/dest1/
SRC3=/u02/dest2/
C1=`find $SRC1 -type f -iname "*_$YYYY$MM$DD*" | wc -l`
C2=`find $SRC2 -type f -iname "*_$YYYY$MM$DD*" | wc -l`
C3=`find $SRC3 -type f -iname "*_$YYYY$MM$DD*" | wc -l`

if [ $C1 -ge 1100 ]; then
        echo "backlog is present"
        else
        cp -v /App-log/ROUTE_LOGS/TATASKY_KOL1_RECON_*$DAY*.csv /u01/Recon_tatasky_Distribution/
        /bin/sh /opt/stlmediationsetup/script/Hourly_Report.sh $DATE1 >> /u01/Recon_tatasky_Distribution/TataSky_KOL1_HourlyRecon_${DAY}_summary.csv
mv /u01/Recon_tatasky_Distribution/TATASKY_KOL1_RECON_*$DAY*.csv  /u01/Recon_tatasky_Distribution/TataSky_KOL1_HourlyRecon_${DAY}_detailed.csv
fi
