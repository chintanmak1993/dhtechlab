
cd /u01/NATDATA/SYSLOG/JUNIPER/Parsing-Input/

rename .gz.warn .gz *.gz.warn
