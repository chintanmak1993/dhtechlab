> /opt/stlmediationsetup/CRESTEL-P-Engine/modules/mediation/logs/MediationServerOut.Log
> /App-log/APPLICATION_LOGS/PROCESSING/logs/MediationServerOut.Log
