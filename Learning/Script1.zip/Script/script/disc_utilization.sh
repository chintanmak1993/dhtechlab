
hostname=`hostname`
log=/u01/STAT/HC
. /opt/stlmediationsetup/script/color.cr

FREE=`free -g  | sed -n '2,2p' | awk ' { print $4 } '`
USED=`free -g  | sed -n '2,2p' | awk ' { print $3 } '`
TOTAL=`free -g  | sed -n '2,2p' | awk ' { print $2 } '`
InCache=`free -g  | sed -n '2,2p' | awk ' { print $6 } '`
TotalSwap=`free -g  | sed -n '3,3p' | awk ' { print $2 } '`
FreeSwap=`free -g  | sed -n '3,3p' | awk ' { print $4 } '`

DAY=`date +%Y%m%d`;
date >>${log}/${hostname}_${DAY}_su.csv

echo -e systemmemory,date,hostname,serverIP,total Memory,Total Free memory,UsedMemory,TotalInCache,TotalSwap,TotalFreeSwap >>${log}/${hostname}_${DAY}_su.csv
echo -e systemmemory,"$DAY,`hostname`,`hostname`,`hostname -i`,${TOTAL},$FREE,$USED,$InCache,$TotalSwap,$FreeSwap" >>${log}/${hostname}_${DAY}_su.csv

. /opt/stlmediationsetup/script/color.cr
THRESOLD=70
LOAD=`uptime`
TEST=`uptime |awk -F ',' '{print$5}'|awk -F '.' '{print$1}'`
uptime1=`uptime |awk -F ',' '{print$4}'|cut -d ':' -f2`
uptime2=`uptime |awk -F ',' '{print$5}'|cut -d ':' -f2`
uptime3=`uptime |awk -F ',' '{print$6}'|cut -d ':' -f2`

ServerUp=`uptime |awk -F ',' '{print$1}'|awk -F ' ' '{print$3" "$4}'`

echo -e systemload,date,hostname,serverIPuptime1,uptime2,uptime3,ServerUpSince >>${log}/${hostname}_${DAY}_su.csv
echo -e systemload,"$DAY,`hostname`,`hostname -i`,$uptime1,$uptime2,$uptime3,$ServerUp" >>${log}/${hostname}_${DAY}_su.csv
. /opt/stlmediationsetup/script/color.cr


THRESHOLD=70
CC=`df -P|grep "/"|awk  '{print$6,"-->>",$5}'|sed 's/%//g'|wc -l`


echo "systemdisk,date,hostname,Server IP,/,/App-log,/u01,/boot,/opt,/dev/shm,/var,/home " >>${log}/${hostname}_${DAY}_su.csv
root=`df -P|grep "/"|grep "/dev/mapper/rhel-root" |awk  '{print$5}'`
Applog=`df -P|grep "/"|grep "/App-log" |awk  '{print$5}'`
u01=`df -P|grep "/" |grep "/u01" |awk  '{print$5}'`
boot=`df -P|grep "/" |grep "/boot" |awk  '{print$5}'| head -1`
opt=`df -P|grep "/" |grep "/opt" |awk  '{print$5}'`
dev_shm=`df -P|grep "/" |grep "/dev/shm" |awk  '{print$5}'`
var=`df -P|grep "/" |grep "/var" |awk  '{print$5}'`
home=`df -P|grep "/" |grep "/home" |awk  '{print$5}'`

echo -e "systemdisk,$DAY,`hostname`,`hostname -i`,$root,$Applog,$u01,$boot,$opt,$dev_shm,$var,$home" >>${log}/${hostname}_${DAY}_su.csv

echo -e "\n" >>${log}/${hostname}_${DAY}_su.csv

BASE_DIR="/u01/NATDATA/SYSLOG/JUNIPER"
TOTAL_FILES=0
YDAY=`date -d "-1 days" +%Y%m%d`;
PHour=`date -d "-1 days" +"%-H"`
TODAY=`date +%Y%m%d`;
MAX_ALLOWED_FILES=1
echo PendingFilecount,ServerHostname,ServerIP,PendingFilePath,PendingFileCount >>${log}/${hostname}_${DAY}_su.csv
for file in `find $BASE_DIR -type d|grep -v STAT|grep -v ARCH|grep -v arch|grep -v DNS|grep -v RECORD|grep -v {YDAY}|grep -v ${TODAY}`
do
                  TOTAL_FILES=`find $file -maxdepth 1 -type f |grep -v {YDAY}|grep -v ${TODAY}| wc -l`
                            if test $TOTAL_FILES -ge $MAX_ALLOWED_FILES
                                                      then
               echo PendingFilecount-${PHour},`hostname`,`hostname -i`,$file,$TOTAL_FILES >>${log}/${hostname}_${DAY}_su.csv
                                                                                                                          fi

               done
