#!/bin/sh
DATE1=`date -d 'now' '+%Y%m%d'`
LOCAL_FOLDER=/opt/APPLICATION_BACKUP
REMOTE_FOLDER=/u02/Collector_Backup
CONFIG=/opt/stlmediationsetup/CRESTEL-P-Engine/modules/mediation

cd $CONFIG
tar cfvz `hostname`_config_$DATE1.tar.gz config

find $CONFIG -type f -iname *$DATE1* -exec mv {} $LOCAL_FOLDER \;
cd $LOCAL_FOLDER

sshpass -p docker scp `hostname`_config_$DATE1.tar.gz docker@192.168.81.31:$REMOTE_FOLDER

find $LOCAL_FOLDER -iname "*.gz" -type f -mtime +3 -exec rm -rf {} \;
