#!/bin/bash
year=`date +%Y -d "1 day ago"`
month=` date +%-m -d "1 day ago"`
day=`date +%-d -d "1 day ago"`
hour=`date +%H -d "1 day ago"`
KOL_eps=`zcat /u01/NATDATA/SYSLOG/STAT/SYSLOG_COLLECTION_SERVICE/$year/$month/$day/*.gz | awk -F ',' '{print $12}' | awk -F ':' '{print $2}' | sort -h | tail -1`
#echo "max_jaipur_eps_count: $jaipur_eps counts"
echo $KOL_eps > /opt/stlmediationsetup/script/license_monitor/KOL_today.txt
