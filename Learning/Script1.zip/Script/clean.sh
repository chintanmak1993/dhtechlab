> /App-log/PROCESSING/logs/MediationServerOut.Log
> /App-log/PROCESSING/logs/MediationServerOut-PROC.Log
