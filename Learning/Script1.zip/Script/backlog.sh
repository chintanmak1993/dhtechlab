#! /bin/bash

SRC=/u02/NATDATA/JUNIPER_INPUT_bkp/
DST=/u01/natdata/natflow/input_test

FDATE=`find /u02/NATDATA/JUNIPER_INPUT_bkp/ -name "*.gz" -type f -exec ls -l {} + | awk -F '_' '{print$2}' | cut -c 1-8 | sort | uniq | head -1`
for i in {00..23}
do
DSTC=`find $DST -name "*" -type f |wc -l`
if [ $DSTC -le 50 ]
then
mv /u01/natdata/natflow/input/*_${FDATE}${i}*.gz /u01/natdata/natflow/input_test
else
echo "Much Files in $DST = $DSTC"
fi
done

