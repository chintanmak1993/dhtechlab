#!/bin/bash

dd=`date +'%d/%b/%Y %H:%M:%S'`

/usr/bin/docker exec -i MediationPEngine_7.10.19 bash <<EOF
su - crestel 2>/dev/null
i=jps -v | grep 9406 | awk -F ' ' '{print $2}'

if [[ $"i" -ne 0 ]]
then
        echo "Service is running"
else
        cd /opt/crestelsetup/crestelpengine/modules/mediation/bin
        sh startServer_9406.sh
        echo "9406 Service started at $dd"
fi
EOF
