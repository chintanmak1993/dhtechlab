#!/bin/bash

dd=`date +'%d/%b/%Y %H:%M:%S'`

status9405=`docker container top MediationPEngine_7.10.19 | grep 9405 | awk -F ' ' '{print$2}'`
status9406=`docker container top MediationPEngine_7.10.19 | grep 9406 | awk -F ' ' '{print$2}'`

if [[ $"status9405" -ne 0 ]]
then
        echo "9405 Service is running at $dd"
else
        echo "9405 Service is not running at $dd"
        sh /home/iplms/scripts/serviceStart_9405.sh
fi

if [[ $"status9406" -ne 0 ]]
then
        echo "9406 Service is running at $dd"
else
        echo "9406 Service is not running at $dd"
        sh /home/iplms/scripts/serviceStart_9406.sh
fi
