#!/bin/sh
DATE1=`date -d 'now' '+%Y%m%d'`
LOCAL_FOLDER=/u02/APPLICATION_BACKUP
REMOTE_FOLDER=/opt1/VIEWER_APP_BACKUP



find /home/docker/MOUNT_PATH/MediationPEngine-7.8.3 -type d -iname *config* -exec cp -ir {} $LOCAL_FOLDER \;
cd $LOCAL_FOLDER
tar cfvz `hostname`_config_$DATE1.tar.gz config
sshpass -p docker scp `hostname`_config_$DATE1.tar.gz docker@192.168.81.32:$REMOTE_FOLDER
rm -rf config

find $LOCAL_FOLDER -iname "*.gz" -type f -mtime +3 -exec rm -rf {} \;
