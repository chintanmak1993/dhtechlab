
#!/bin/sh
. /opt/iplms/script/color.cr
P1=/u01/COLLECTION/INPUT/192.168.210.65
P2=/u01/COLLECTION/INPUT/PARSE_ROOT/OUTPUT
P3=/u01/COLLECTION/INPUT/PROC_ROOT/INPUT/
P4=/u01/COLLECTION/INPUT/PROC_ROOT/OUTPUT

C1=`find $P1 -type f |wc -l`
C2=`find $P2 -type f |wc -l`
C3=`find $P3 -type f |wc -l`
C4=`find $P4 -type f |wc -l`

echo -e "CIRCLE : $HOSTNAME:`hostname -i`"
echo -e Parsing_Input,Parsing_Output,Processing_Input,Distribution_Input >> /opt/iplms/script/pending.txt
echo -e $C1,$C2,$C3,$C4 >> /opt/iplms/script/pending.txt
