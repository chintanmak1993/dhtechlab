#!/bin/bash/
P1=/u02/USGDATA/USG_INPUT/;
P2=/u02/USGDATA/USG_INPUT1/;
P3=/IPLMS-4/USGDATA/USG_ARCH_Temp/;
P4=/IPLMS-4/USGDATA/USG_OUTPUT1/;

cd $P1
for i in `ls -1 *.csv`
do
cat $i|awk -F',' -vOFS=',' '{if ( ( $10 >= 500 ) && ( $9 == 3 ) )  $10 = 500; print $0}' >> $P2/$i
mv $i $P3/
done
