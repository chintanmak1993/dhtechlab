find /u01/COLLECTION/INPUT/archived/. -iname "*.gz" -type f -mtime +5 -exec rm -rf {} \;
#find /u01/COLLECTION/INPUT/DIST_ARCH/archived/. -iname "*.gz" -type f -mtime +3 -exec rm -rf {} \;
find /u01/COLLECTION/INPUT/DIST_ARCH/ARCH_PURGE/. -iname "*.gz" -type f -mtime +2 -exec rm -rf {} \;
find /u01/COLLECTION/INPUT/PROC_ROOT/filtered/. -iname "*.inp" -type f -exec rm -rf {} \;
