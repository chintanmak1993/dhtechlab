#!/bin/bash

DEST_SERVER=10.198.11.2
DEST_USER=billing
DEST_PASSWD=billing123
DEST_FOLDER=/var/opt/services/.apps/pgw_cdr/
LOCAL_FOLDER=/u02/mediation/Services/meddata/parse/input/PGW/PW001/
LOCAL_FOLDER_RA=/u02/mediation/Services/meddata/dist_ra/input/PGW/PW001/
LOCAL_FOLDER_ARCH=/archivedata/mediation/Services/meddata/archive/PGW/PW001/

sshpass -p "$DEST_PASSWD" sftp ${DEST_USER}@${DEST_SERVER}:/${DEST_FOLDER} <<<"ls EPGLA1_PGW*" |head -100  > /home/crestel/script/collection.txt

sed -i '1,2d' /home/crestel/script/collection.txt

for i in `cat /home/crestel/script/collection.txt`
do
sshpass -p "$DEST_PASSWD" sftp $DEST_USER@$DEST_SERVER:$DEST_FOLDER/ <<<"get $i $LOCAL_FOLDER"
cp $LOCAL_FOLDER/$i $LOCAL_FOLDER_RA/
cp $LOCAL_FOLDER/$i $LOCAL_FOLDER_ARCH/
#sshpass -p "$DEST_PASSWD" sftp $DEST_USER@$DEST_SERVER:$DEST_FOLDER/ <<<"rename $i $i.done"
sshpass -p "$DEST_PASSWD" sftp $DEST_USER@$DEST_SERVER:$DEST_FOLDER/ <<<"rm $i"
done
