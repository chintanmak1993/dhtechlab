#!/bin/bash
lock_path=/tmp/
############# LOCK FILE ########################
if test -f ${lock_path}.internal_sftp_move_dest1.lock
        then
                echo "script is already running"
                exit
        else
                echo " creating lock file "
                touch ${lock_path}.internal_sftp_move_dest1.lock
fi;

DIR_1=/opt1/SYSLOG/SFTP_INPUT
BKP_DIR=/opt1/SYSLOG/SFTP_PURGE
SCP_DIR=/sec_iplms_data2/NATDATA_RAW
LOG=/opt1/SYSLOG/rsync/
SEND_DATE=`date '+%Y%m%d'`

#for i in `ls -rt ${DIR_1} | head -n500`
FDATE=`find /u01/natdata/natflow/input -name "*.gz" -type f -exec ls -l {} + | awk -F '_' '{print$2}' | cut -c 1-10 | sort | uniq | head -1`
for i in {00..23}
do
DSTC=`find $DST -name "*" -type f |wc -l`
if [ $DSTC -le 500 ]
then
cp ${DIR_1}/$i ${BKP_DIR}/$i
rsync --remove-source-files -av -e ${DIR_1}/$i ${SCP_DIR} --log-file=${LOG}RSYNC_INTERNAL_FILE_${SEND_DATE}_Dest1.log
done

rm ${lock_path}.internal_sftp_move_dest1.lock
echo "LOCK IS REMOVED"