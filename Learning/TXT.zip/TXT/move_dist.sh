#!/bin/bash
source_path=/u01/NATDATA/SYSLOG/JUNIPER/error/DISTRIBUTION_SERVICE-000-SFTP_DISTRIBUTION_DRIVER-0/Processing-Output-000/ASCII_COMPOSER_PLUGIN-1/FILE/2021
for i in `find $source_path -type f -iname "*.gz"`;
do
rsync --remove-sent-files -av -e ssh $i /u01/NATDATA/SYSLOG/JUNIPER/Processing-Output
done


source_path1=/u01/NATDATA/SYSLOG/JUNIPER/error/DISTRIBUTION_SERVICE-000-SFTP_DISTRIBUTION_DRIVER-0/Processing-Output-000/DEFAULT/FILE/2021
for i in `find $source_path1 -type f -iname "*.gz"`;
do
rsync --remove-sent-files -av -e ssh $i /u01/NATDATA/SYSLOG/JUNIPER/Processing-Output/
done
